#include "Trigger.h"

Trigger::Trigger(GameObject* parent) : Object3D(parent)
{
}

Trigger::~Trigger()
{
}

void Trigger::Initialize()
{
}

void Trigger::Update()
{
}

void Trigger::Draw()
{
}
