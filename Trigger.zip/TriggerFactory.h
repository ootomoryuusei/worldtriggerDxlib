#pragma once
#include"Trigger.h"
#include"BaseFactory.h"

class TriggerFactory : public Factory<Trigger> {
public:
	static TriggerFactory& Instance() {
		static TriggerFactory instance;
		return instance;
	}
private:
};